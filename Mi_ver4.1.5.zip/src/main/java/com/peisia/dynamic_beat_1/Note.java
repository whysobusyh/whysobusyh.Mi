package com.peisia.dynamic_beat_1;

import javax.swing.ImageIcon;
import java.awt.Image;
import java.awt.Graphics2D;

public class Note extends Thread {
	// 각각의 노트 또한 하나의 부분적인 기능으로서 떨어지는 역할을 수행해야하기 때문에 스레드를 상속

	private Image noteBasicImage = new ImageIcon(Main.class.getResource("../images/noteBasic.png")).getImage();
	// 노트 이미지 객체를 생성
	private int x, y = 580 - ( 1000 / Main.SLEEP_TIME * Main.NOTE_SPEED ) * Main.REACH_TIME ;
	// 1초 뒤에 판정라인에 오게 하기 위해서 연산식
	// y좌표 580에 위치 1000은 1초를 표기 
	//  Main.NOTE_SPPED는 내려가는 속도이니 곱
	// judgementLine의 y좌표 - {( 1000 / Main.SLEEP_TIME ) * Main.NOTE_SPEED}; 로 봐야함
	// y좌표 - ( 1초당 몇번 반복되는지 * 1회당 y좌표 변화량 ) 
	// 현재 노트의 x와 y좌표
	private String noteType;
	// 노트 타입 생성

	private boolean proceeded = true;
	// 현재 노트의 진행여부 체크
	
	public String getNoteType() {
		return noteType;
	}
	
	public boolean isProceeded() {
		return proceeded;
	}
	// get함수
	
	public void close() {
		proceeded = false;
	}
	// 노트가 성공적으로 입력헀을때 해당 노트가 더이상 이동하지 못하는 처리를 하기 위한 함수 
	
	
	public Note(String noteType) {
		// 생성자 노트 타입
		
		if(noteType.equals("S")) {
			x = 228;
		}else if(noteType.equals("D")) {
			x = 332;
		}else if(noteType.equals("F")) {
			x = 436;
		}else if(noteType.equals("Space")) {
			x = 540;
		}else if(noteType.equals("J")) {
			x = 744;
		}else if(noteType.equals("K")) {
			x = 848;
		}else if(noteType.equals("L")) {
			x = 952;
		}
		
		this.noteType = noteType;
	}

	public void screenDraw(Graphics2D g) {
		// 노트 이미지를 그려주기 위해 screenDraw를 그려줌
		if (noteType.equals("Space")) {
			//스페이스바를 눌렀을때 쓰일 예정
			g.drawImage(noteBasicImage, x, y, null);
			g.drawImage(noteBasicImage, x + 100, y, null);
		} else {
			g.drawImage(noteBasicImage, x, y, null);
			// 일반 자판을 눌렀을때 쓰일 예정

		}
	}
	
	public void drop() {
		// 노트가 떨어지는 함수
		y+= Main.NOTE_SPEED; // 현재 설정은 7
		// y좌표가 7만큼 추가됨
		if(y > 620) {
			// y가 많이 내려갔다면 Miss 판정이 나오도록 하고 사라지게 함
			System.out.println("Miss");
			close();
		}
	}
	
	@Override
	public void run() {
		//게임이 실행되면
		try {
			while(true) {
				drop();
				// y좌표가 증가되서 떨어지도록 보이게 하는 함수가 실행
				if(proceeded) {
					//노트가 움직이고 있다면
					Thread.sleep(Main.SLEEP_TIME);
					// 움직일 수 있게 함
				}else {
					// 노트들의 작업처리가 모두 끝이 났다면 false로 바꿔서 스레드가 정지하도록 함
					interrupt();
					// 스레드 정지 함수
					break;
				}
				// 0.01초만큼 쉬게 해주었다가 다시 반복
				// 1초에 100번 실행 1초에 y좌표가 700만큼 떨어짐
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void judge() {
		if(y >= 613) {
			System.out.println("Late");
			close();
		}else if(y >= 600) {
			System.out.println("Good");
			close();
		}else if(y >= 587) {
			System.out.println("Great");
			close();
		}else if(y >= 573) {
			System.out.println("Perfect");
			close();
		}else if(y >= 565) {
			System.out.println("Great");
			close();
		}else if(y >= 550) {
			System.out.println("Good");
			close();
		}else if(y >= 535) {
			System.out.println("Early");
			close();
		}
	}
	
}
