package com.peisia.spring.dto;

import lombok.Data;

@Data
public class Login_Dto {
	private int login_Test;
	private String c_Nickname;
	private String c_ID;
	private String c_PW;
}
