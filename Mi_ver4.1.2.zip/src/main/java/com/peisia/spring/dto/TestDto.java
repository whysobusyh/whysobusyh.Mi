package com.peisia.spring.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class TestDto {
	private int no ;
	private String str_data;
}
