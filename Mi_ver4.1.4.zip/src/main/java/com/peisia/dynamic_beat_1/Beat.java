package com.peisia.dynamic_beat_1;

import lombok.Data;

@Data
public class Beat {
	private int time;
	private String noteName;
	// getter setter함수는 @Data로 대체
	
	public Beat(int time, String noteName) {
		// 생성자 함수 생성
		super();
		this.time = time;
		this.noteName = noteName;
	}
	
	
	
}
