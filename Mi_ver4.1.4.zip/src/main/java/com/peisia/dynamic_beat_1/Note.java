package com.peisia.dynamic_beat_1;

import javax.swing.ImageIcon;
import java.awt.Image;
import java.awt.Graphics2D;

public class Note extends Thread {
	// 각각의 노트 또한 하나의 부분적인 기능으로서 떨어지는 역할을 수행해야하기 때문에 스레드를 상속

	private Image noteBasicImage = new ImageIcon(Main.class.getResource("../images/noteBasic.png")).getImage();
	// 노트 이미지 객체를 생성
	private int x, y = 580 - ( 1000 / Main.SLEEP_TIME * Main.NOTE_SPEED ) * Main.REACH_TIME ;
	// 1초 뒤에 판정라인에 오게 하기 위해서 연산식
	// y좌표 580에 위치 1000은 1초를 표기 
	//  Main.NOTE_SPPED는 내려가는 속도이니 곱
	// judgementLine의 y좌표 - {( 1000 / Main.SLEEP_TIME ) * Main.NOTE_SPEED}; 로 봐야함
	// y좌표 - ( 1초당 몇번 반복되는지 * 1회당 y좌표 변화량 ) 
	// 현재 노트의 x와 y좌표
	private String noteType;
	// 노트 타입 생성

	public Note(String noteType) {
		// 생성자 노트 타입
		
		if(noteType.equals("S")) {
			x = 228;
		}else if(noteType.equals("D")) {
			x = 332;
		}else if(noteType.equals("F")) {
			x = 436;
		}else if(noteType.equals("Space")) {
			x = 540;
		}else if(noteType.equals("J")) {
			x = 744;
		}else if(noteType.equals("K")) {
			x = 848;
		}else if(noteType.equals("L")) {
			x = 952;
		}
		
		this.noteType = noteType;
	}

	public void screenDraw(Graphics2D g) {
		// 노트 이미지를 그려주기 위해 screenDraw를 그려줌
		if (noteType.equals("Space")) {
			//스페이스바를 눌렀을때 쓰일 예정
			g.drawImage(noteBasicImage, x, y, null);
			g.drawImage(noteBasicImage, x + 100, y, null);
		} else {
			g.drawImage(noteBasicImage, x, y, null);
			// 일반 자판을 눌렀을때 쓰일 예정

		}
	}
	
	public void drop() {
		// 노트가 떨어지는 함수
		y+= Main.NOTE_SPEED; // 현재 설정은 7
		// y좌표가 7만큼 추가됨
	}
	
	@Override
	public void run() {
		//게임이 실행되면
		try {
			while(true) {
				drop();
				// y좌표가 증가되서 떨어지도록 보이게 하는 함수가 실행
				Thread.sleep(Main.SLEEP_TIME);
				// 0.01초만큼 쉬게 해주었다가 다시 반복
				// 1초에 100번 실행 1초에 y좌표가 700만큼 떨어짐
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
